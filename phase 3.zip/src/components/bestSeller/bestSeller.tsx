import React from "react";

interface props {}

const BestSeller: React.FC<props> = () => {
  return <div>BestSeller</div>;
};

export default BestSeller;

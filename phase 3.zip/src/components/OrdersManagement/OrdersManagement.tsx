import React from "react";

interface props {}

const OrdersManagement: React.FC<props> = () => {
  return <div>OrdersManagement</div>;
};

export default OrdersManagement;

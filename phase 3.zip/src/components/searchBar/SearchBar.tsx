import React from "react";

interface props {}

const SearchBar: React.FC<props> = () => {
  return <div>SearchBar</div>;
};

export default SearchBar;

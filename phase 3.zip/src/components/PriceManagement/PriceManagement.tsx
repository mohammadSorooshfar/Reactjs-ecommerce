import React from "react";

interface props {}

const PriceManagement: React.FC<props> = () => {
  return <div>PriceManagement</div>;
};

export default PriceManagement;

import React from "react";

interface props {}

const CartItem: React.FC<props> = () => {
  return <div>CartItem</div>;
};

export default CartItem;

import React from "react";

interface props {}

const ProductsManagement: React.FC<props> = () => {
  return <div>ProductsManagement</div>;
};

export default ProductsManagement;

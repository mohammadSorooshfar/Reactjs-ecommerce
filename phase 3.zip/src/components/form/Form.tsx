import React from "react";

interface props {}

const Form: React.FC<props> = () => {
  return <div>Form</div>;
};

export default Form;

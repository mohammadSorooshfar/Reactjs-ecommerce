import React from "react";

interface props {}

const Cart: React.FC<props> = () => {
  return <div>Cart</div>;
};

export default Cart;

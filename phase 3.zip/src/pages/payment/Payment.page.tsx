import React from "react";

interface props {}

const Payment: React.FC<props> = () => {
  return <div>Payment</div>;
};

export default Payment;

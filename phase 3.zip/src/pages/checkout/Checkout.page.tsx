import React from "react";

interface props {}

const Checkout: React.FC<props> = () => {
  return <div>Checkout</div>;
};

export default Checkout;

<h1 align="center">Tehran shoes project</h1>
<h3 align="center">Maktab75 Final Project - Mohammad Sorooshfar</h3>
  
</br></br>

<strong>Phase 1 : </strong>
</br>

<ul>
  <li>Create repository</li>
  <li>Create folders</li>
  <li>Install packages</li>
  <li>Create Layouts</li>
  <li>Create Routes</li>
  <li>Create component map</li>
</ul>.

import React from "react";

interface props {}

const CheckoutResult: React.FC<props> = () => {
  return <div>CheckoutResult</div>;
};

export default CheckoutResult;
